${ws}${te_set.module}${te_set.clear}( ${te_select_related.result_var} );
