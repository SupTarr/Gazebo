${ws}${te_select_related.result_var} = 0;
