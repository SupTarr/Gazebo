${ws}${te_select_related.result_var} = ( 0 != ${te_lnk.left} ) ? ${cast}${te_lnk.left}->${te_lnk.linkage} : 0;
