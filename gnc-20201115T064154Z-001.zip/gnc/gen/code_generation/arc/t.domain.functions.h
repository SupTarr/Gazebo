/*
 * UML Domain Functions (Synchronous Services)
 */
${function_declarations}
