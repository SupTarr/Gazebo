${ws}${te_set.module}${te_set.clear}( ${te_select_related.result_var} ); /* ${te_select_related.result_var_OAL} (${te_class.Key_Lett}) */"
