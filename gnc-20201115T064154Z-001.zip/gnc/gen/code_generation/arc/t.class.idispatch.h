extern void ${te_class.dispatcher}( ${te_eq.base_event_type} * );
