${ws}else if ( ${condition_te_val.buffer} ) {
