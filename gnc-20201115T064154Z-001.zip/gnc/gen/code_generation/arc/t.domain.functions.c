.//
.if ( te_sys.InstanceLoading )
extern void mark_pass( c_t * );
#define T_T(x) ( 0 == x ) ? s : strcat(s,x)
.end if
/*
 * UML Domain Functions (Synchronous Services)
 */
${function_definitions}
.//
