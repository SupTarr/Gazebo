${ws}if ( 0 != ${te_lnk.left} ) {
