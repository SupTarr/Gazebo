${ws}${te_select_related.result_var} = ${cast}${te_lnk.left}->${te_lnk.linkage};
