.if ( te_sync.IsSafeForInterrupts )
void ${te_sync.intraface_method}(${te_aba.ParameterDeclaration});
.end if
${te_aba.ReturnDataType} ${te_aba.GeneratedName}(${te_aba.ParameterDeclaration});
