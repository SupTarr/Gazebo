/*----------------------------------------------------------------------------
 * File:  Control_Controller_class.h
 *
 * Class:       Controller  (Controller)
 * Component:   Control
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#ifndef CONTROL_CONTROLLER_CLASS_H
#define CONTROL_CONTROLLER_CLASS_H

#ifdef	__cplusplus
extern	"C"	{
#endif

/*
 * Structural representation of application analysis class:
 *   Controller  (Controller)
 */
struct Control_Controller {
  Escher_StateNumber_t current_state;
  /* application analysis class attributes */
};



#define Control_Controller_MAX_EXTENT_SIZE 10
extern Escher_Extent_t pG_Control_Controller_extent;

/*
 * instance event:  Controller1:'start'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Control_Controllerevent1;
extern const Escher_xtUMLEventConstant_t Control_Controllerevent1c;
/*
 * instance event:  Controller2:'ready'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Control_Controllerevent2;
extern const Escher_xtUMLEventConstant_t Control_Controllerevent2c;
/*
 * union of events targeted towards 'Controller' state machine
 */
typedef union {
  Control_Controllerevent1 controller1_1;  
  Control_Controllerevent2 controller2_2;  
} Control_Controller_Events_u;
/*
 * enumeration of state model states for class
 */
#define Control_Controller_STATE_1 1  /* state [1]:  (Unnamed State) */
#define Control_Controller_STATE_2 2  /* state [2]:  (takeoff) */
#define Control_Controller_STATE_3 3  /* state [3]:  (1house) */
#define Control_Controller_STATE_4 4  /* state [4]:  (2house) */
#define Control_Controller_STATE_5 5  /* state [5]:  (3house) */
#define Control_Controller_STATE_6 6  /* state [6]:  (4house) */
#define Control_Controller_STATE_7 7  /* state [7]:  (5house) */
#define Control_Controller_STATE_8 8  /* state [8]:  (6house) */
#define Control_Controller_STATE_9 9  /* state [9]:  (7house) */
#define Control_Controller_STATE_10 10  /* state [10]:  (8house) */
#define Control_Controller_STATE_11 11  /* state [11]:  (9house) */
#define Control_Controller_STATE_12 12  /* state [12]:  (10house) */
#define Control_Controller_STATE_13 13  /* state [13]:  (beforwall) */
#define Control_Controller_STATE_16 14  /* state [16]:  (land) */
#define Control_Controller_STATE_17 15  /* state [17]:  (jumpwall) */
/*
 * enumeration of state model event numbers
 */
#define CONTROL_CONTROLLEREVENT1NUM 0  /* Controller1:'start' */
#define CONTROL_CONTROLLEREVENT2NUM 1  /* Controller2:'ready' */
extern void Control_Controller_Dispatch( Escher_xtUMLEvent_t * );

#ifdef	__cplusplus
}
#endif

#endif  /* CONTROL_CONTROLLER_CLASS_H */
